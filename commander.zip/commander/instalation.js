const fs = require('fs');
const readline = require('readline');
const os = require('os');
const chalk = require('chalk');
const clear = require('clear-console');
clear();

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})

rl.question(chalk.cyanBright("Would you like a shortcut on your desktop? ") + chalk.greenBright("(yes or no) ") + chalk.yellowBright(), (ans) => {
    if (ans != "true" || ans != "false") {
        console.log(chalk.redBright("You must input a yes or a no. (Restart the program to reselect.)"))
        return process.exit()
    };
    if (ans === "true") {
        console.log(chalk.cyanBright("Downloading needed files..."));
        fs.appendFileSync('bat.db', `${process.cwd()} && cls && start commander.exe`)
        fs.writeFileSync(`${os.homedir()}\\Desktop\\commander.bat`, fs.readFileSync('bat.db'));
        console.log("Desktop shortcut created.")
    }
    setTimeout(() => {
        require('./index')
    }, 1000);
});