const fs = require('fs');

if (fs.readFileSync('./installed.db', 'utf-8') === "false") {
    return require('./instalation')
} else {
    return require('./index')
}