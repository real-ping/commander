//modules

const chalk = require('chalk');
const fs = require('fs');
const os = require('os');
const clear = require('clear-console');
const readline = require('readline');
const ncmd = require('node-cmd');
const path = require("path");

// variables

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})
let dir = fs.readFileSync("dir.db", 'utf-8');
let date = new Date()
let prompt = `${chalk.cyan(dir)} ${chalk.cyanBright(date.getHours() + ":" + date.getMinutes() + ":" + (Number.parseInt(date.getSeconds()) + 1))}${chalk.greenBright("> ")}`
let autoClear = (fs.readFileSync("ac.db", 'utf-8').toLowerCase() === 'true')

// start up
ncmd.run('title commander')
clear();
rl.setPrompt(prompt);
rl.prompt()

rl.on('line', input => {
    date = new Date()
    prompt = `${chalk.cyan(dir)} ${chalk.cyanBright(date.getHours() + ":" + date.getMinutes() + ":" + (Number.parseInt(date.getSeconds()) + 1))}${chalk.greenBright("> ")}`;
    rl.setPrompt(prompt)
    if (autoClear) clear();
    let args = input.split(/ +/g);
    let command = args.shift().toLowerCase();
    let autoPrompt = true;

    if (command === "mkfile") {
        autoPrompt = false;
        if (!args[0]) {
            console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("mkfile <file name>"));
            return rl.prompt()
        }
        let file = `${dir}\\${args[0]}`;
        let files = fs.readdirSync(dir, 'utf-8');
        let count = -1;
        files.forEach(file => {
            count++
            files[count] = file.toLowerCase()
        })
        if (files.includes(args[0].toLowerCase())) {
            console.log(chalk.redBright("That folder already exist."));
            return rl.prompt()
        }
        fs.writeFile(file, "", (err) => {
            if (err) {
                console.log(chalk.redBright("There was an error creating that file, error:\n") + err);
                return rl.prompt()
            } else {
                console.log(chalk.greenBright("File successfuly made."));
                rl.prompt()
            }
        })
    } else if (command === "rmfile") {
        autoPrompt = false;
        if (!args[0]) {
            console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("rmfile <file name>"));
            return rl.prompt()
        }
        let file = `${dir}\\${args[0]}`;
        fs.unlink(file, (err) => {
            if (err) console.log(chalk.redBright("There was an error removing that file, error:\n") + err);
            else {
                console.log(chalk.greenBright("File successfuly removed."));
                rl.prompt()
            }
        })
    } else if (command === "run") {
        autoPrompt = false;
        if (!args[0]) {
            console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("run <command>"));
            return rl.prompt()
        }
        ncmd.run(`cd ${dir} && ` + args.join(' '), (err, data) => {
            if (err) return console.log(chalk.redBright(`There was an error running that command (${args.join(' ')}), error:\n`) + err);
            console.log(chalk.greenBright("Command has been successfuly ran."))
            if (data) {
                console.log(chalk.cyanBright("Data: \n") + chalk.whiteBright(data))
            }
            rl.prompt()
        })
    } else if (command === "files" || command === "folders" || command === "content") {
        autoPrompt = false
        fs.readdir(dir, (err, files1) => {
            if (err) {
                if (err.code === "ENOENT") return console.log(chalk.red("There was an error looking for that directory."));
                else return console.log(chalk.red("There was an error in your current directory, error: \n" + err));
            }
            let data = files1;
            let foldersData = data.filter(x => !x.includes('.') || x.startsWith(".")),
                filesData = data.filter(x => x.includes('.'));
            let files, folders;

            foldersData.forEach(folder => {
                if (!folders) folders = chalk.cyan(folder);
                else folders = folders + "\n" + chalk.cyan(folder);
            });
            filesData.forEach(file => {
                if (!files) files = chalk.cyan(file);
                else files = files + "\n" + chalk.cyan(file);
            })

            let report = "" +
                chalk.greenBright("====================") + chalk.yellowBright('[') + chalk.cyanBright("Folders") + chalk.yellowBright(']') + chalk.greenBright("====================") + "\n" +
                chalk.magentaBright(`${foldersData.length} Folders\n`) + folders + "\n" +
                chalk.greenBright("=====================") + chalk.yellowBright('[') + chalk.cyanBright("Files") + chalk.yellowBright(']') + chalk.greenBright("=====================") + "\n" +
                chalk.magentaBright(`${filesData.length} Files\n`) + files + "\n" +
                chalk.greenBright("=================================================");
            console.log(report);
            rl.prompt()
        });

    } else if (command === "open") {
        autoPrompt = false;
        ncmd.run(`cd ${dir} && start .`, (err, data) => {
            if (err) {
                console.log(chalk.redBright("There was an error opening your file-explorer for that directory, error:\n" + err))
                return rl.prompt()
            } else {
                console.log(chalk.greenBright("File-explorer now launching.."));
                return rl.prompt()
            }
        })
    } else if (command === "start") {
        if (!args[0]) return console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("start <file name>"));
        rl.prompt()
        autoPrompt = false;
        let files = fs.readdirSync(dir);
        let foldersData = data.filter(x => !x.includes('.'));

        if (foldersData.includes(args[0])) {
            ncmd.run(`cd ${dir} && start ${args[0]}`, (err, data) => {
                if (err) return console.log(chalk.red("There was an error starting that file, error: \n" + err));
                else {
                    console.log(chalk.greenBright("File successfuly started."));
                    rl.prompt();
                }
            })
        }

    } else if (command === "cd") {
        if (!args[0]) return console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("cd <directory location>"));
        autoPrompt = false;
        let newdir = path.resolve(dir, args[0]);
        fs.readdir(newdir, (err, files) => {
            if (err) {
                console.log(chalk.red("Thats an invalid directory: ") + chalk.redBright(newdir));
                return rl.prompt()
            } else {
                fs.writeFileSync("dir.db", newdir.toString());
                dir = newdir;
                prompt = `${chalk.cyan(dir)} ${chalk.greenBright("> ")}`
                rl.setPrompt(prompt)
                rl.prompt()
            }
        })

    } else if (command === "vscode") {
        autoPrompt = false;
        ncmd.run(`cd ${dir} && code .`, (err, data) => {
            if (err) return console.log(chalk.red("There was an error launching vscode, error: \n" + err));
            else {
                console.log(chalk.greenBright("vscode is now launching..."));
                rl.prompt()
            }
        })
    } else if (command === "npm" || command === "node") {
        if (!args[0] || args[0] === "help" || args[0] === '?') {
            let report = chalk.yellowBright("built-in node or npm commands:\n") +
                gen('i <module name>', "Install a npm package.") +
                gen('r <module name>', "Remove a npm package.") +
                gen('v | -v | version', "Tells you your current node version.", true)
            console.log(report)

            function gen(cmd, help, last) {
                if (last) return chalk.cyanBright(cmd) + chalk.gray(' - ') + chalk.greenBright(help)
                else return chalk.cyanBright(cmd) + chalk.gray(' - ') + chalk.greenBright(help) + "\n"
            }
        } else if (args[0] === '-v' || args[0] === "version" || args[0] === "v") {
            autoPrompt = false;
            ncmd.run(`node -v`, (err, data) => {
                if (err) {
                    console.log(chalk.redBright("There was an error getting your node version.Error: \n") + err);
                    return rl.prompt()
                }
                console.log(chalk.greenBright("node version: " + data));
                rl.prompt()
            })
        } else if (args[0] === 'i' || args[0] === "install") {
            if (!args[1]) return console.log(chalk.redBright("Your missing arguments, please try 'npm i <npm package name>'"));
            autoPrompt = false;
            fs.writeFileSync(`${process.cwd()}\\node_install.bat`, `title Install npm package... && cls && cd ${dir} && echo Installing npm package: ${args[01]} && npm i ${args[1]}`);
            ncmd.run(`cd ${process.cwd()} && start node_install.bat`, (err, data) => {
                if (err) {
                    console.log(chalk.redBright("There was an error starting your node install system.Error: \n") + err);
                    return rl.prompt()
                }
                console.log(chalk.greenBright("node installation has been completed."));
                return rl.prompt()
            })
        } else if (command === "node") {
            if (!args[0]) return console.log(chalk.redBright("Your missing arguments, please try 'node <directory or filename>' to start a node file."));
            autoPrompt = false;
            fs.writeFileSync(`${process.cwd()}\\node_start.bat`, `title Starting node files... && cls && cd ${dir} && node ${args[0]}`);
            ncmd.run(`cd ${process.cwd()} && start node_start.bat`, (err, data) => {
                if (err) {
                    console.log(chalk.redBright("There was an error starting your node file.Error: \n") + err);
                    return rl.prompt()
                }
                console.log(chalk.greenBright("node file has successfully ran."));
                return rl.prompt()
            });

        }
    } else if (command === "exit" || command === "quit") {
        rl.close()
        process.exit()
    } else if (command === "restart" || command === "reboot") {
        fs.writeFileSync(`${process.cwd()}\\reboot.bat`, `cd ${process.cwd()} && node .`);
        ncmd.run(`cd ${process.cwd()} && start reboot.bat`, (err, data) => {
            if (err) return console.log(chalk.red('There was an error rebooting commander.'));

        })
        setTimeout(() => {
            console.log(chalk.greenBright("Reboot started"))
            ncmd.run('exit', (err, data) => {
                if (err) {
                    console.log(chalk.red("There was an error in the reboot."))
                }
                process.exit()
            })
        }, 500);
    } else if (command === "mkdir") {
        autoPrompt = false;
        if (!args[0]) {
            console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("mkdir <folder name>"));
            return rl.prompt()
        }
        let folder = `${dir}\\${args[0]}`;
        fs.mkdir(folder, (err) => {
            if (err) {
                if (err.code === "EEXIST") {
                    console.log(chalk.redBright("That folder already exist."));
                    return rl.prompt()
                }
                console.log(chalk.redBright("There was an error making that folder, error:\n") + err);
                return rl.prompt()
            } else {
                console.log(chalk.greenBright("Folder successfuly created."));
                rl.prompt()
            }
        })
    } else if (command === "rmdir") {
        autoPrompt = false;
        if (!args[0]) {
            console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("rmdir <folder name>"));
            return rl.prompt()
        }
        let folder = `${dir}\\${args[0]}`;
        fs.rmdir(folder, (err) => {
            if (err) console.log(chalk.redBright("There was an error removing that folder, error:\n") + err);
            else {
                console.log(chalk.greenBright("Folder successfuly removed."));
                rl.prompt()
            }
        })
    } else if (command === "autoclear" || command === "ac") {
        autoClear = !autoClear;
        fs.writeFileSync('ac.db', autoClear.toString().toLowerCase())
        if (autoClear) console.log(chalk.cyanBright("Autoclear is now set to: ") + chalk.greenBright("true"))
        else console.log(chalk.cyanBright("Autoclear is now set to: ") + chalk.redBright("false"))
    } else if (command === "cls" || command === "clear") {
        clear()
    } else if (command === "help" || command === "?") {
        let report = "" +
            gen("mkfile <file name>", "creates a file.") +
            gen("rmfile <file name>", "removes a file.") +
            gen("run <command>", "runs a command as a command prompt.") +
            gen("files | folders | content", "displays all folders and files.") +
            gen('open', "opens your current directory in a file-explorer.") +
            gen("start <file name>", "starts up a file.") +
            gen('cd <path>', "change you current directory.") +
            gen("vscode", "launches vscode in your current directory.") +
            gen("mkdir <folder name>", "creates a folder.") +
            gen('rmdir <folder name>', "removes a folder.") +
            gen('ac | autoclear', "toggles between true of false to weather or not the console auto-clears on each command.") +
            gen("cls | clear", "clears the console.") +
            gen("help | ?", "this help menu.") +
            gen('quit | exit', "Exit the program.") +
            gen('node <args> | npm <args>', "Run some node commands") +
            gen('reboot | restart', 'restart the program.')
        gen("read <file name>", "displays the files content.", true)
        console.log(report)

        function gen(cmd, help, last) {
            if (!last) return chalk.cyanBright(cmd) + chalk.gray(' - ') + chalk.greenBright(help) + "\n"
            else return chalk.cyanBright(cmd) + chalk.gray(' - ') + chalk.greenBright(help)
        }
    } else if (command === "read") {
        if (!args[0]) return console.log(chalk.red("Your missing args, please type: ") + chalk.redBright("read <file name & extension>"));
        if (!args[0].includes(".")) return console.log(chalk.red("Your file name must include its extension, please type: ") + chalk.redBright("read <file name & extension>"));
        autoPrompt = false
        fs.readFile(`${dir}\\${args[0]}`, (err, data) => {
            if (err) {
                if (err.code === "ENOENT") {
                    console.log(chalk.redBright("There isn't a valid file."));
                    return rl.prompt()
                } else {
                    console.log(chalk.redBright("There was an error reading that file, error:\n") + err);
                    return rl.prompt()
                }

            };
            let report = "" +
                chalk.cyanBright(`File: ${args[0]}\n`) +
                chalk.whiteBright(data);
            console.log(report);
            rl.prompt()
        })
    } else {
        console.log(chalk.red("Unknown command, type '") + chalk.redBright("help") + chalk.red("' for help."))
    }

    if (autoPrompt) rl.prompt(prompt);

})